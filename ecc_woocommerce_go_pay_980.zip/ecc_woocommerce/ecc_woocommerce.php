<?php
/*
Plugin Name: eCommerceConnect
Plugin URI: https://ecommerce.upc.ua/
Description: One-Click Payment with eCommerceConnect
Version: 0.13
Author: UPC
Author URI: https://upc.ua/
License: GPL2
*/

include_once "functions.php";

if (!defined('ABSPATH')) exit; // Exit if accessed directly
if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) return;

add_action('plugins_loaded', 'woocommerce_ecc_init', 0);
function woocommerce_ecc_init()
{
    add_action('init', 'translations_ecc');
    function translations_ecc()
    {
        load_plugin_textdomain('ecc', FALSE, dirname(plugin_basename(__FILE__)) . '/languages/');
    }

    class WC_ecc extends WC_Payment_Gateway
    {
        var $action_url;
        var $notify_url;
        var $merchantID;
        var $terminalID;

        function __construct()
        {
            global $woocommerce;

            $this->plugin_url = path2url(realpath(__DIR__));
            //$this->action_url = 'https://secure.upc.ua/go/pay';          // https://ecg.test.upc.ua/go/enter
            $this->action_url = 'https://secure.upc.ua/go/pay';

            $this->id = 'ecc';
            $this->method_title = 'eCommerceConnect';
            $this->init_form_fields();
            $this->init_settings();
            $this->title = $this->settings['title'];
            $this->icon = $this->plugin_url . '/images/visa_PNG14_2 x42.png';
            $this->description = $this->settings['description'];
            $this->has_fields = false;
            $this->merchantID = $this->settings['merchant_id'];
            $this->terminalID = $this->settings['terminal_id'];

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(&$this, 'process_admin_options'));
            add_action('woocommerce_receipt_ecc', array(&$this, 'receipt_page'));
            add_action('woocommerce_api_wc_ecc', array(&$this, 'check_bank_response'));
            add_action('woocommerce_api_' . strtolower(get_class($this)), array(&$this, 'callbackAction'));
            add_action('woocommerce_thankyou_ecc', array(&$this, 'thankyou_page'));
        }

        function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'ecc'),
                    'type' => 'checkbox',
                    'label' => __('Enable ECC Payment Plugin.', 'ecc'),
                    'default' => 'no'),
                'title' => array(
                    'title' => __('Title:', 'ecc'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', 'ecc'),
                    'default' => __('eCommerceConnect', 'ecc')),
                'description' => array(
                    'title' => __('Description:', 'ecc'),
                    'type' => 'textarea',
                    'description' => __('This controls the description which the user sees during checkout.', 'ecc'),
                    'default' => __('The credit cards, issued by all the banks of the world, including Visa Electron/ Maestro.', 'ecc')),
                'merchant_id' => array(
                    'title' => __('Merchant ID', 'ecc'),
                    'type' => 'text',
                    'description' => __('Given to Merchant by ECC', 'ecc')),
                'terminal_id' => array(
                    'title' => __('Terminal ID', 'ecc'),
                    'type' => 'text',
                    'description' => __('Given to Merchant by ECC', 'ecc'))
            );
        }

        public function callbackAction()
        {
//            http://rolf.in.ua/avaldemo/wordpress/wp-api/wc_ecc

            $order = wc_get_order($_POST['OrderID']);

            if ($_POST['TranCode'] === '000') {
                $order->set_status("wc-completed");
                $order->save();
            } else {
                $order->set_status("wc-failed");
                $order->save();
            }

            echo "MerchantID = " . $_POST['MerchantID'] . "\n";
            echo "TerminalID = " . $_POST['TerminalID'] . "\n";
            echo "OrderID = " . $_POST['OrderID'] . "\n";
            echo "Currency = " . 980 . "\n";
            echo "TotalAmount = " . $_POST['TotalAmount'] . "\n";
            echo "XID = " . $_POST['XID'] . "\n";
            echo "PurchaseTime = " . $_POST['PurchaseTime'] . "\n";
            echo "ApprovalCode= " . $_POST['ApprovalCode'] . "\n";
            echo "SD= " . $_POST['SD'] . " \n";
            echo "TranCode= " . $_POST['TranCode'] . " \n";
            echo "Response.action= approve \n";
            echo "Response.reason= ok \n";
            echo "Response.forwardUrl=  \n";
            die;
        }

        private function checkSignature()
        {
            $MerchantID = $_POST['MerchantID'];
            $TerminalID = $_POST['TerminalID'];
            $OrderID = $_POST['OrderID'];
            $PurchaseTime = $_POST['PurchaseTime'];
            $TotalAmount = $_POST['TotalAmount'];
            $CurrencyID = 980;
            $XID = $_POST['XID'];
            // $SD = $_POST['SD'];
            $TranCode = $_POST['TranCode'];
            $ApprovalCode = $_POST['ApprovalCode'];
            $signature = base64_decode($_POST['Signature']);


            $data = $MerchantID . ";" . $TerminalID . ";" . $PurchaseTime . ";" . $OrderID . ";" . $XID . ";" . $CurrencyID . ";" . $TotalAmount . ";;" . $TranCode . ";" . $ApprovalCode . ";";


            //$base_path = plugin_dir_path(__FILE__);

            //$crtid = openssl_pkey_get_public(file_get_contents($base_path . '/keys/work-server.pub')); // test-server

            //$verify_status = openssl_verify($data, $signature, $crtid);

            return true;
        }

        function get_pages($title = false, $indent = true)
        {
            $wp_pages = get_pages('sort_column=menu_order');
            $page_list = array();
            if ($title) $page_list[] = $title;
            foreach ($wp_pages as $page) {
                $prefix = '';
                // show indented child pages?
                if ($indent) {
                    $has_parent = $page->post_parent;
                    while ($has_parent) {
                        $prefix .= ' - ';
                        $next_page = get_page($has_parent);
                        $has_parent = $next_page->post_parent;
                    }
                }
                // add to page list array array
                $page_list[$page->ID] = $prefix . $page->post_title;
            }

            return $page_list;
        }

        public function admin_options()
        {
            echo '<h3>' . __('ECC Payment Gateway', 'ecc') . '</h3>';

            echo
                "<img src=\"" . $this->plugin_url . "/images/ecc_logo.gif\" />
                <p>Send this link to a UPC specialist to return to the store after payment:</p>
                <ul>
				<code>" . get_bloginfo("url") . "/wc-api/wc_ecc/</code>
				</ul>
				<hr>";

            echo '<table class="form-table">';
            // Generate the HTML For the settings form.
            $this->generate_settings_html();

            echo '</table>';

        }

        function process_payment($order_id)
        {
            $order = new WC_Order($order_id);
            return array(
                'result' => 'success',
                'redirect' => add_query_arg('order', $order->id, add_query_arg('key', $order->order_key, get_permalink(woocommerce_get_page_id('pay'))))
            );
        }

        function receipt_page($order)
        {
            echo '<p>' . __('Pay through your bank', 'ecc') . '</p>';
            echo $this->generate_bank_form($order);
        }

        function generate_bank_form($order_id)
        {
            global $woocommerce;
            $order = new WC_Order ($order_id);

            $merchantID = $this->merchantID;
            $terminalID = $this->terminalID;
            $purchaseTime = date("ymdHis");
            $totalAmount = $order->get_total() * 100;  // здесь нужно указать всю сумму В КОПЕЙКАХ!!!

            $data = "$merchantID;$terminalID;$purchaseTime;$order_id;5;$totalAmount;;";

            //$pemFile = __DIR__ . '/keys/' . $merchantID . '.pem';
            //$fp = fopen($pemFile, "r");

            //$priv_key = fread($fp, 8192);
            //fclose($fp);
            //$pkeyid = openssl_get_privatekey($priv_key);
            //openssl_sign($data, $signature, $pkeyid);
            //openssl_free_key($pkeyid);
            //$b64sign = base64_encode($signature); //Подпись данных в формате base64

            $args = array(
                'Version' => '1',
//                'redirect' => $this->VK_RETURN,
                'MerchantID' => $merchantID,
                'TerminalID' => $terminalID,
                'TotalAmount' => $totalAmount,
                'Currency' => '980',
                'locale' => 'en',
//                'SD' => '',
                'OrderID' => $order_id,
                'PurchaseTime' => $purchaseTime,
                'PurchaseDesc' => "Оплата " . $order_id
                //'Signature' => $b64sign
            );



            if (count($order->get_used_coupons()) > 0) {
                $desc = 'Купоны: "' . implode("\", \"", $order->get_used_coupons()) . '" (общая сумма скидки: ' . $order->get_total_discount() . '). ' . $desc;
            }

            if ($order->customer_message != '') $desc .= '. Сообщение: ' . $order->customer_message;

            $args_array = array();
            $tt = '';
            foreach ($args as $key => $value) {
                $tt.= $key .' - '. $value.';
                ';
                $args_array[] = '<input type="hidden" name="' . esc_attr($key) . '" value="' . esc_attr($value) . '" />';
            }
//            <form action="' . esc_url($this->action_url) . '" method="POST" id="paymaster_form">' . "\n" .
            $htm .= '
            <form action="https://secure.upc.ua/go/pay" method="POST" id="paymaster_form">' . "\n" .
                implode("\n", $args_array) .
                '<span id="ppform">
        			<input type="submit" class="button btn btn-default" id="submit_paymaster_payment_form" value="' . __('Purchase', 'woocommerce') . '" style="display:inline-block" /> <a class="button btn alt btn-black" href="' . $order->get_cancel_order_url() . '">' . __('Back', 'woocommerce') . '</a>
        			</span>' . "\n" .
                '</form>
        			';
            echo $htm;
        }

        function check_bank_response()
        {

            echo "check_bank_response";

            @ob_clean();

            if (!empty($_REQUEST)) {
                header('HTTP/1.1 200 OK');
                do_action("valid_request", $_REQUEST);

            } else {
                wp_die("No response from the bank");
            }
        }

        function process_gateway_response($posted)
        {

            global $woocommerce;

            $order_id = $_POST["OrderID"];
            echo "OrderID=$order_id";
            echo "<br />";

            $order = new WC_Order($order_id);

            $order->payment_complete();
            $order->add_order_note(' response from gateway : OK ');
            $woocommerce->cart->empty_cart();

            print_r($woocommerce);

            echo '<br>';

            $order = new WC_Order($order_id);
            // $order_id =
            $order_key = $order->get_order_key();
            $url = get_site_url() . '/' . 'checkout' . '/' . 'order-received' . '/' . $order_id . '/' . '?' . 'key=' . $order_key;
            wp_safe_redirect($url);

        }

    }

    function woocommerce_add_ecc_gateway($methods)
    {
        $methods[] = 'WC_ecc';
        return $methods;
    }

    add_filter('woocommerce_payment_gateways', 'woocommerce_add_ecc_gateway');

}